 <!-- <footer class="footer">
            <div class="container">
              <div class="row align-items-center flex-row-reverse">
                <div class="col-md-12 col-sm-12 text-center">
                <a href="#" style="color:#6a64e8;" target="_blank"> <?php echo 'User Guide'; ?></a> | <a href="#" style="color:#6a64e8;" >Privacy Policy</a> | <?php echo 'Copy'; ?> © <?php echo date('Y'); ?> &nbsp;&nbsp;<a href="#" target="_blank">TruTravel</a>  |  <?php echo 'All rights reserved'; ?>.
                </div>
              </div>
            </div>
          </footer> -->
          <!-- End Footer-->
        </div>
      </div>
  
   <!-- Back to top -->
		<a href="#top" id="back-to-top"><i class="fas fa-angle-up "></i></a>

		<!--Jquery js -->
		<script src="<?php echo base_url('assets/admin/js/jquery.js');?>"></script>

		<!--Jquery.Sparkline js -->
		<script src="<?php echo base_url('assets/admin/js/vendors/jquery.sparkline.min.js');?>"></script>

		<!--Circle-Progress js -->
		<script src="<?php echo base_url('assets/admin/js/vendors/circle-progress.min.js');?>"></script>

		<!--Jquery.rating js -->
		<script src="<?php echo base_url('assets/admin/plugins/jquery.rating/jquery.rating-stars.js');?>"></script>

		<!--Bootstrap.min js-->
		<script src="<?php echo base_url('assets/admin/plugins/bootstrap/popper.min.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/plugins/bootstrap/js/bootstrap.min.js');?>"></script>

		<!-- Side menu js -->
		<script src="<?php echo base_url('assets/admin/plugins/sidemenu/js/sidemenu.js');?>"></script>

		<!-- Sidemenu-responsive-tabs js-->
		<script src="<?php echo base_url('assets/admin/plugins/sidemenu-responsive-tabs/js/sidemenu-responsive-tabs.js');?>"></script>

		<script src="<?php echo base_url('assets/admin/js/left-menu.js');?>"></script>

		<!-- P-scroll js -->
		<!-- p-scroll bar js-->
		<script src="<?php echo base_url('assets/admin/plugins/p-scroll/p-scroll.js');?>"></script>
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll-1.js');?>"></script>

		<!-- peitychart -->
		<script src="<?php echo base_url('assets/admin/plugins/peitychart/jquery.peity.min.js'
		);?>"></script>

		<!-- WYSIWYG Editor js -->
		<script src="<?php echo base_url('assets/admin/plugins/jquery.richtext/jquery.richtext.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/plugins/jquery.richtext/richText1.js');?>"></script>

		<!--ckeditor js-->
		<script src="<?php echo base_url('assets/admin/plugins/tinymce/tinymce.min.js');?>"></script>

		<!--Counters -->
		<script src="<?php echo base_url('assets/admin/plugins/counters/counterup.min.js');?>"></script>
		<script src="<?php echo base_url('assets/admin/plugins/counters/waypoints.min.js');?>"></script>

		<!-- Sidebar js -->
		<script src="<?php echo base_url('assets/admin/plugins/sidebar/sidebar.js');?>"></script>
		<!--Index js -->
		<script src="<?php echo base_url('assets/admin/js/index.js');?>"></script>

		<!-- Richtext js -->
		<script src="<?php echo base_url('assets/admin/js/richtext.js');?>"></script>

		<!-- custom js -->
		<script src="<?php echo base_url('assets/admin/js/custom.js');?>"></script>
  </body>
  </html>