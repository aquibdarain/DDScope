<?php include("application/views/header_view.php");?>
 

    <section class="innerbanner ">
    </section>
    <section class="bannermainbg">
      <div class="container">
        <div class="row">
          <div class="col-lg-7">
            <div class="col-lg-12 blog">
              <div
                id="carouselExampleCaptions1"
                class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000" >
                <!-- Wrapper for carousel items -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/Pu2QwQVbmo8"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/EZvCpjfWRPI"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/Tyr9Ba9JEpY"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/uxH7t14zdGQ"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/G9t5y_AflIM"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/8HTCqWIwE-w"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/IOlX--QkPrc"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/MtWSBbgQZUQ"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/009CrzVj6mc"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/wEnHlmMUr8w"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/QGCtWkxZmj4"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/MymQomnaJoQ"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>                                          <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/wFk124epsoQ"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/d3XzMX6ungI"   
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <div class="row justify-content-center">
                      <div class="col-lg-12">
                        <div class="card-box shadow rounded">
                          <iframe
                            width="100%"
                            height="350"
                            class="video"
                            src="https://www.youtube.com/embed/pNh5aCNfhCg"   
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
                <button
                  class="carousel-control-prev"
                  type="button"
                  data-bs-target="#carouselExampleCaptions1"
                  data-bs-slide="prev"
                >
                  <span class="carousel-control-prev-icon" aria-hidden="true"
                    ><svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      class="bi bi-chevron-left"
                      viewBox="0 0 16 16"
                    >
                      <path
                        fill-rule="evenodd"
                        d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"
                      ></path></svg></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button
                  class="carousel-control-next"
                  type="button"
                  data-bs-target="#carouselExampleCaptions1"
                  data-bs-slide="next"
                >
                  <span class="carousel-control-next-icon" aria-hidden="true"
                    ><svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      class="bi bi-chevron-right"
                      viewBox="0 0 16 16"
                    >
                      <path
                        fill-rule="evenodd"
                        d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"
                      ></path></svg></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>

              <div class="floating-button">
                <p>
                  <a href="<?php echo base_url('Home'); ?>"
                    ><button style="background-color: grey; border-color: grey;" type="button" class="btn btn-primary">
                      Video
                    </button></a
                  >
                </p>
                <p>
                  <a href="<?php echo base_url('Home/ads'); ?>"
                    ><button style="background-color: darkgreen; border-color: darkgreen;" type="button" class="btn btn-info">
                      Ads&nbsp;&nbsp;&nbsp;
                    </button></a
                  >
                </p>
              </div>
            </div>
            <div class="col-lg-12 caption">
              <h1>
                De-Stress your stock portfolio using the stressless trading system!
              </h1>
              <p>Continuous Income Generation Through Trading</p>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="phonebg">
            <img src="<?php echo base_url('images/dozendiamond-phonebg.png');?>">
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <p>
              <a href="<?php echo base_url('');?>"> Home </a> |<a href="<?php echo base_url('Home/vision');?>">
                Our vision</a
              >
              | <a href="<?php echo base_url('Home/career');?>">Careers</a> | <a href="<?php echo base_url('Home/video');?>" >Videos</a> | <a href="<?php echo base_url('Home/ads');?>">Ads</a>
            </p>
            <p>contact@dozendiamonds.com</p>
            <p>Copyright © 2023 DozenDiamonds. All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </footer>

    <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js');?>"></script>
    <!--     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>-->
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.4.1.min.js');?>"></script>
    <script>
      $(document).ready(function () {
        var carousel = $(".carousel");
        var videos = carousel.find(".video");

        // Function to check if any video is playing
        function isAnyVideoPlaying() {
          var playing = false;
          videos.each(function() {
            var video = $(this).get(0);
            if (video && !video.paused) {
              playing = true;
              return false; // Exit the loop early
            }
          });
          return playing;
        }
        // Pause all videos when next slide is shown
        carousel.on("slide.bs.carousel", function (event) {
          if (carousel.data('pause-on-video') && isAnyVideoPlaying()) {
            event.preventDefault(); // Prevent moving to the next slide
          }
          var currentSlide = $(event.relatedTarget);
          var currentVideo = currentSlide.find(".video");

          // Pause all videos except the current one
          videos.not(currentVideo).each(function () {
            var videoSrc = $(this).attr("src");
            $(this).attr("src", videoSrc); // This stops the video
          });
        });
      });
    </script>
    
  </body>
</html>
